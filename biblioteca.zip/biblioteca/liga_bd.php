<?php
// 4 parametros para ligação (Servidor, utilizador, senha e base de dados)
$servidor="localhost";
$user="root";
$senha="";
$bd="bd_biblioteca";

$ligacao = mysqli_connect($servidor,$user,$senha,$bd);
if ($ligacao->connect_error){
    die(mysqli_connect_error($ligacao));
}

?>