<html>
    <head>
        <meta charset="utf-8">
        <title>Gestão de  Biblioteca</title>
    </head>
    <body>
        <h1>Alteração de Manuais</h1>
        <form method="post" action="alterar2.php">
        Qual o manual a alterar: <select name="cp_id">
        <?php
        include 'liga_bd.php';
        
        $sql ="SELECT * FROM tb_manual order by titulo";
        // a variavel resultado vai guardar todos os dados de todos os clientes
        $resultado =mysqli_query($ligacao, $sql) or die(mysqli_error($ligacao)); 
        //enquanto conseguir ler dados do array resultado imprime
        while($linha = mysqli_fetch_assoc($resultado)){
            echo "<option value='".$linha['id']."'>".$linha['titulo']."</option>";
        }
        mysqli_close($ligacao);
        ?>
        </select>
        <input type="submit" value="Alterar">
        </form>
        <br/>
        <a href="index.html" target="_self">Volta ao Menu</a>
    </body>
</html>