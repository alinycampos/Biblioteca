<html>
    <head>
        <meta charset="utf-8">
        <title>Gestão de  Biblioteca</title>
        <meta http-equiv="refresh" content="3;url=index.html">
    </head>
    <body>
        <h1>Alterar Manuais</h1>
        <?php
        include 'liga_bd.php';
        
        
        $sql ="UPDATE tb_manual SET
        titulo='$_POST[titulo]',
        num_pag='$_POST[num_pag]',
        text_descr='$_POST[text_descr]',
        peso_kb='$_POST[peso_kb]',
        autor='$_POST[autor]'  WHERE id=$_POST[cp_id]";
    //echo $sql;  
        
        if (mysqli_query($ligacao, $sql))
            echo "<h3>Manual alterado com sucesso!</h3>"; 
        mysqli_close($ligacao); echo "<br/>";
        ?>
        <br/><h4>Aguarde que vai ser redirecionado</h4><a href="index.html" target="_self">Volta ao Menu</a>
    </body>
</html>