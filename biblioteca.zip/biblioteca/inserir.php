<html>
    <head>
        <meta charset="utf-8">
        <title>Gestão de Biblioteca</title>
        
        <meta http-equiv="refresh" content="5;url=index.html">
    </head>
    <body>
        <h1>Inserir Manuais</h1>
        <?php
        include 'liga_bd.php';

        $sql = "INSERT INTO tb_manual (titulo, num_pag, text_descr, peso_kb, autor) VALUES
            ('$_POST[titulo]','$_POST[num_pag]', '$_POST[text_descr]', '$_POST[peso_kb]',
            '$_POST[autor]')";
        if (mysqli_query($ligacao, $sql)) 
           echo "<h3>Livro inserido com sucesso!</h3>";
        mysqli_close($ligacao); echo "<br/>;"      
        ?>
        <br/><h4>Aguarde que vai ser redirecionado</h4><a href="index.html" target="_self">Volta ao Menu</a>
    </body>
</html>